<div id="banner">
  <div class="bannercontainer clearfix">
    <div class="car-container">
        <div class="car-img-container">
        <img src="images/redcar.png" alt="Trolltunga Norway" >
        <div class="car-description">
        <p>CAR NAME AND DESCRIPTION <span>AND CHARACTERISTICS</span></p>
        <a target="_blank" href="javascript:;">LEARN MORE</a>
        </div>
        </div>
        <div class="car-img-container">
        <img src="images/whitecar.png" alt="Forest">
        <div class="car-description">
        <p>CAR NAME AND DESCRIPTION <span>AND CHARACTERISTICS</span></p>
        <a target="_blank" href="javascript:;">LEARN MORE</a>
        </div>
        </div>
        <div class="car-img-container">
        <img class="bigcar" src="images/stripecar.png" alt="Forest" >
        <div class="car-description">
        <p>CAR NAME AND DESCRIPTION <span>AND CHARACTERISTICS</span></p>
        <a target="_blank" href="javascript:;">LEARN MORE</a>
       </div>
       </div>
        <div class="car-img-container">
        <img src="images/backcar.png" alt="Trolltunga Norway" >
        <div class="car-description">
        <p>CAR NAME AND DESCRIPTION <span>AND CHARACTERISTICS</span></p>
        <a target="_blank" href="javascript:;">LEARN MORE</a>
        </div>
        </div>
        <div class="car-img-container">
        <img src="images/bently-banner.png" alt="Forest">
        <div class="car-description">
         <p>CAR NAME AND DESCRIPTION <span>AND CHARACTERISTICS</span></p>
        <a target="_blank" href="javascript:;">LEARN MORE</a>
        </div>
        </div>
        <div class="car-img-container">
        <img class="bigcar" src="images/bmw-banner.png" alt="Forest">
        <div class="car-description">
         <p>CAR NAME AND DESCRIPTION <span>AND CHARACTERISTICS</span></p>
        <a target="_blank" href="javascript:;">LEARN MORE</a>
        </div>
        </div>
    </div>

  </div>

</div>
